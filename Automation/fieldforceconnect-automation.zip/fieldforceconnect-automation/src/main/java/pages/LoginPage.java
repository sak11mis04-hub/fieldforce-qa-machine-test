package pages;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class LoginPage {

    private WebDriver driver;
    private WebDriverWait wait;

    private By emailField =
            By.xpath("//input[@placeholder='Enter Email or Mobile Number']");

    private By passwordField =
            By.xpath("//input[@placeholder='Password']");

    private By signInButton =
            By.cssSelector("button[type='submit']");

    public LoginPage(WebDriver driver) {

        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(20));
    }

    public void enterEmail(String email) {

        WebElement emailBox = wait.until(
                ExpectedConditions.visibilityOfElementLocated(emailField)
        );

        emailBox.clear();
        emailBox.sendKeys(email);
    }

    public void enterPassword(String password) {

        WebElement passwordBox = wait.until(
                ExpectedConditions.visibilityOfElementLocated(passwordField)
        );

        passwordBox.clear();
        passwordBox.sendKeys(password);
    }

    public void clickSignIn() {

        WebElement button;

        try {

            button = wait.until(
                    ExpectedConditions.elementToBeClickable(signInButton)
            );

        } catch (Exception e) {

            By alternativeButton = By.xpath(
                    "//button[contains(translate(normalize-space(.), " +
                    "'ABCDEFGHIJKLMNOPQRSTUVWXYZ', " +
                    "'abcdefghijklmnopqrstuvwxyz'), 'sign in')]"
            );

            button = wait.until(
                    ExpectedConditions.elementToBeClickable(alternativeButton)
            );
        }

        button.click();
    }

    public void login(String email, String password) {

        enterEmail(email);
        enterPassword(password);
        clickSignIn();
    }
}
