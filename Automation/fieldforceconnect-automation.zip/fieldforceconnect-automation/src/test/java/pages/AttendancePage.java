package pages;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class AttendancePage {

    private WebDriver driver;
    private WebDriverWait wait;

    private By attendanceMenu =
            By.xpath("//span[normalize-space()='Attendance']");

    private By sakshiUser =
            By.xpath("//*[normalize-space()='Sakshi']");

    private By waitingForPunchIn =
            By.xpath("//*[contains(normalize-space(),'Waiting for punch in')]");

    private By punchedInStatus =
            By.xpath(
                "//*[contains(translate(normalize-space(.),"
                + "'ABCDEFGHIJKLMNOPQRSTUVWXYZ',"
                + "'abcdefghijklmnopqrstuvwxyz'),"
                + "'punched in')]"
            );

    private By punchInIcon =
            By.xpath("//button[@aria-label='User Location']");

    private By[] confirmButtonCandidates = new By[] {
            By.xpath("//button[contains(translate(normalize-space(.),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'),'punch')]"),
            By.xpath("//button[contains(translate(normalize-space(.),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'),'confirm')]"),
            By.xpath("//button[contains(translate(normalize-space(.),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'),'submit')]"),
            By.xpath("//button[contains(translate(normalize-space(.),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'),'save')]"),
            By.xpath("//img[contains(@src,'attendance')]/ancestor::button[1]"),
            By.xpath("//*[contains(@class,'MuiFab')]"),
            By.xpath("//button[contains(@style,'position: fixed') or contains(@style,'position: absolute')][last()]")
    };

    private By toast =
            By.xpath(
                "//*[contains(@class,'toast') "
                + "or contains(@class,'Toast') "
                + "or contains(@class,'snackbar') "
                + "or contains(@class,'alert')]"
            );

    public AttendancePage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(20));
    }

    private void safeClick(By locator) {

        JavascriptExecutor js = (JavascriptExecutor) driver;

        int attempts = 0;
        Exception lastException = null;

        while (attempts < 3) {

            attempts++;

            try {

                WebElement element =
                        wait.until(ExpectedConditions.elementToBeClickable(locator));

                js.executeScript(
                        "arguments[0].scrollIntoView({block:'center'});",
                        element
                );

                sleep(400);

                try {

                    element.click();
                    return;

                } catch (ElementClickInterceptedException e) {

                    System.out.println(
                            "Attempt " + attempts +
                            ": click intercepted, retrying with JS click."
                    );

                    sleep(1500);

                    WebElement freshElement =
                            wait.until(ExpectedConditions.elementToBeClickable(locator));

                    js.executeScript(
                            "arguments[0].click();",
                            freshElement
                    );

                    return;
                }

            } catch (StaleElementReferenceException e) {

                System.out.println(
                        "Attempt " + attempts +
                        ": element went stale, retrying."
                );

                lastException = e;
                sleep(800);

            } catch (Exception e) {

                System.out.println(
                        "Attempt " + attempts +
                        ": click failed (" +
                        e.getClass().getSimpleName() +
                        "), retrying."
                );

                lastException = e;
                sleep(800);
            }
        }

        throw new RuntimeException(
                "safeClick failed after 3 attempts for locator: " + locator,
                lastException
        );
    }

    private void sleep(long millis) {

        try {

            Thread.sleep(millis);

        } catch (InterruptedException ie) {

            Thread.currentThread().interrupt();
        }
    }

    public void openAttendance() {

        safeClick(attendanceMenu);

        wait.until(
                ExpectedConditions.urlContains("/attendance")
        );

        System.out.println("Attendance page opened.");
    }

    public void selectSakshi() {

        safeClick(sakshiUser);

        System.out.println("Sakshi selected.");

        wait.until(
                ExpectedConditions.visibilityOfElementLocated(
                        waitingForPunchIn
                )
        );
    }

    public void punchIn() {

        safeClick(punchInIcon);

        System.out.println(
                "User Location icon clicked - map page should open."
        );

        sleep(2000);

        boolean confirmClicked = false;

        for (By candidate : confirmButtonCandidates) {

            List<WebElement> found =
                    driver.findElements(candidate);

            if (!found.isEmpty() &&
                    found.get(0).isDisplayed()) {

                System.out.println(
                        "Found confirm button using locator: "
                        + candidate
                );

                try {

                    safeClick(candidate);

                    confirmClicked = true;

                    break;

                } catch (Exception e) {

                    System.out.println(
                            "Candidate locator matched but click failed, "
                            + "trying next: " + candidate
                    );
                }
            }
        }

        if (!confirmClicked) {

            System.out.println(
                    "WARNING: No explicit confirm button found on "
                    + "the map page. Continuing to verification."
            );

        } else {

            System.out.println(
                    "Punch In confirmed via map page button."
            );
        }

        waitForPunchResult();
    }

    private void waitForPunchResult() {

        WebDriverWait resultWait =
                new WebDriverWait(driver, Duration.ofSeconds(10));

        try {

            resultWait.until(
                    ExpectedConditions.or(
                            ExpectedConditions.presenceOfElementLocated(
                                    punchedInStatus
                            ),
                            ExpectedConditions.invisibilityOfElementLocated(
                                    waitingForPunchIn
                            )
                    )
            );

            System.out.println("Punch In result detected.");

        } catch (Exception e) {

            System.out.println(
                    "Punch In result was not detected."
            );

            printToastMessage();
        }
    }

    public boolean isPunchInSuccessful() {

        try {

            if (!driver.findElements(punchedInStatus).isEmpty()) {

                System.out.println(
                        "Punch In successful - status changed."
                );

                return true;
            }

        } catch (Exception e) {

        }

        try {

            wait.until(
                    ExpectedConditions.invisibilityOfElementLocated(
                            waitingForPunchIn
                    )
            );

            System.out.println(
                    "Punch In successful - waiting status disappeared."
            );

            return true;

        } catch (Exception e) {

        }

        printToastMessage();

        System.out.println(
                "Punch In could not be verified."
        );

        return false;
    }

    public String getToastMessage() {

        WebDriverWait toastWait =
                new WebDriverWait(driver, Duration.ofSeconds(10));

        try {

            WebElement toastElement =
                    toastWait.until(
                            ExpectedConditions.visibilityOfElementLocated(
                                    toast
                            )
                    );

            return toastElement.getText().trim();

        } catch (Exception e) {

            return "";
        }
    }

    private void printToastMessage() {

        try {

            List<WebElement> messages =
                    driver.findElements(toast);

            for (WebElement element : messages) {

                if (element.isDisplayed()) {

                    String message =
                            element.getText().trim();

                    if (!message.isEmpty()) {

                        System.out.println(
                                "Application message: " + message
                        );
                    }
                }
            }

        } catch (Exception e) {

            System.out.println(
                    "Could not read application message."
            );
        }
    }
}
