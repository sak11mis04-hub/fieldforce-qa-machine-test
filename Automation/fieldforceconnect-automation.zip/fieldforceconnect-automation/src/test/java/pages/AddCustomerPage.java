package pages;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class AddCustomerPage {

    private WebDriver driver;
    private WebDriverWait wait;

    public AddCustomerPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(20));
    }



    private By manageButton =
            By.xpath("//button[contains(normalize-space(),'Manage')]");

    private By newCustomerOption =
            By.xpath("//*[normalize-space()='New Customer']");


    private By customerName =
            By.xpath(
                "//*[contains(normalize-space(),'Lead/Customer Name')]/following::input[1]"
            );

    private By contactPerson =
            By.xpath(
                "//*[normalize-space()='Contact Person Name']/following::input[1]"
            );

    private By mobileNumber =
            By.xpath(
                "//*[normalize-space()='Mobile No']/following::input[1]"
            );

    private By email =
            By.xpath(
                "//*[normalize-space()='Email']/following::input[1]"
            );

    private By designation =
            By.xpath(
                "//*[normalize-space()='Contact Person Designation']/following::input[1]"
            );

    private By contactLocation =
            By.xpath(
                "//*[normalize-space()='Contact Person Location']/following::input[1]"
            );

    private By address =
            By.xpath(
                "//*[normalize-space()='Address']/following::input[1]"
            );

    private By saveButton =
            By.xpath(
                "//button[contains(translate(normalize-space(.),"
                + "'ABCDEFGHIJKLMNOPQRSTUVWXYZ',"
                + "'abcdefghijklmnopqrstuvwxyz'),'save')]"
            );

    private By customerTable =
            By.xpath("//table");



    private void click(By locator) {

        WebElement element =
                wait.until(ExpectedConditions.elementToBeClickable(locator));

        try {
            element.click();
        } catch (Exception e) {

            JavascriptExecutor js =
                    (JavascriptExecutor) driver;

            js.executeScript("arguments[0].click();", element);
        }
    }

    private void enter(By locator, String value) {

        WebElement element =
                wait.until(ExpectedConditions.visibilityOfElementLocated(locator));

        element.clear();
        element.sendKeys(value);
    }



    public void openNewCustomer() {

        click(manageButton);

        wait.until(
                ExpectedConditions.visibilityOfElementLocated(newCustomerOption)
        );

        click(newCustomerOption);

        wait.until(
                ExpectedConditions.visibilityOfElementLocated(customerName)
        );

        System.out.println("New Customer form opened.");
    }



    public void enterCustomerName(String name) {
        enter(customerName, name);
    }

    public void enterContactPerson(String name) {
        enter(contactPerson, name);
    }

    public void enterMobile(String mobile) {
        enter(mobileNumber, mobile);
    }

    public void enterEmail(String emailAddress) {
        enter(email, emailAddress);
    }

    public void enterDesignation(String value) {
        enter(designation, value);
    }

    public void enterLocation(String value) {
        enter(contactLocation, value);
    }

    public void enterAddress(String value) {
        enter(address, value);
    }



    public void saveCustomer() {

        click(saveButton);

        System.out.println("Save button clicked.");


        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }



    public boolean isCustomerDisplayed(String customerNameValue) {

        By customer =
                By.xpath(
                    "//*[normalize-space()="
                    + "'" + customerNameValue + "']"
                );

        try {

            WebElement element =
                    new WebDriverWait(driver, Duration.ofSeconds(15))
                    .until(
                        ExpectedConditions.visibilityOfElementLocated(customer)
                    );

            return element.isDisplayed();

        } catch (Exception e) {

            System.out.println(
                    "Customer not found: " + customerNameValue
            );

            return false;
        }
    }

    public String getCurrentUrl() {
        return driver.getCurrentUrl();
    }
}
