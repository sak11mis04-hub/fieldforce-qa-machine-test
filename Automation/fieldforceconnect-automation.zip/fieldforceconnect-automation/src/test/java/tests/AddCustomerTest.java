package tests;

import base.BaseTest;
import pages.AddCustomerPage;
import pages.LoginPage;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class AddCustomerTest extends BaseTest {


    @DataProvider(name = "customerData")
    public Object[][] customerData() {

        return new Object[][] {

            {
                "Automation Customer 01",
                "Automation Contact",
                "9876543210",
                "automationcustomer01@gmail.com",
                "Manager",
                "Delhi",
                "Automation Test Address"
            },

            {
                "Automation Customer 02",
                "Test Contact",
                "9876543211",
                "automationcustomer02@gmail.com",
                "Executive",
                "Delhi",
                "Automation Test Address 2"
            }
        };
    }



    @Test(dataProvider = "customerData")
    public void addCustomerTest(
            String customerName,
            String contactPerson,
            String mobile,
            String email,
            String designation,
            String location,
            String customerAddress) {



        String password =
                System.getenv("FIELD_FORCE_PASSWORD");

        Assert.assertNotNull(
                password,
                "FIELD_FORCE_PASSWORD environment variable is not set."
        );

        LoginPage loginPage =
                new LoginPage(driver);

        loginPage.login(
                "Sakshi02mishra11@gmail.com",
                password
        );

        wait.until(
                ExpectedConditions.urlContains("/dashboard")
        );

        System.out.println("Login successful.");


        AddCustomerPage addCustomerPage =
                new AddCustomerPage(driver);

        addCustomerPage.openNewCustomer();

        addCustomerPage.enterCustomerName(customerName);

        addCustomerPage.enterContactPerson(contactPerson);

        addCustomerPage.enterMobile(mobile);

        addCustomerPage.enterEmail(email);

        addCustomerPage.enterDesignation(designation);

        addCustomerPage.enterLocation(location);

        addCustomerPage.enterAddress(customerAddress);

        System.out.println(
                "Customer form filled for: " + customerName
        );



        addCustomerPage.saveCustomer();



        boolean customerAdded =
                addCustomerPage.isCustomerDisplayed(customerName);

        Assert.assertTrue(
                customerAdded,
                "Customer was not found after saving: "
                        + customerName
        );

        System.out.println(
                "========================================"
        );

        System.out.println(
                "ADD CUSTOMER TEST PASSED"
        );

        System.out.println(
                "Customer: " + customerName
        );

        System.out.println(
                "Mobile: " + mobile
        );

        System.out.println(
                "Email: " + email
        );

        System.out.println(
                "========================================"
        );
    }
}
