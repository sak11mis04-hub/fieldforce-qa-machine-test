package tests;

import base.BaseTest;
import pages.LoginPage;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class LoginTest extends BaseTest {

    @DataProvider(name = "loginData")
    public Object[][] loginData() {

        return new Object[][] {
            {
                "Sakshi02mishra11@gmail.com",
                System.getenv("FIELD_FORCE_PASSWORD")
            }
        };
    }

    @Test(dataProvider = "loginData")
    public void loginTest(String email, String password) {

        Assert.assertNotNull(
                password,
                "FIELD_FORCE_PASSWORD is not set."
        );

        LoginPage loginPage = new LoginPage(driver);

        loginPage.login(email, password);

        wait.until(
                ExpectedConditions.urlContains("/dashboard")
        );

        Assert.assertTrue(
                driver.getCurrentUrl().contains("/dashboard"),
                "Login failed. Dashboard was not opened."
        );

        System.out.println("LOGIN TEST PASSED");
    }
}
