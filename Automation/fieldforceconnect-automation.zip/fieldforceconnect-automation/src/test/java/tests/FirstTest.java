package tests;

import base.BaseTest;
import org.testng.annotations.Test;

public class FirstTest extends BaseTest {

    @Test
    public void openLoginPage() {

        System.out.println("Login page opened successfully.");

        System.out.println("Page Title: " + driver.getTitle());
    }
}
