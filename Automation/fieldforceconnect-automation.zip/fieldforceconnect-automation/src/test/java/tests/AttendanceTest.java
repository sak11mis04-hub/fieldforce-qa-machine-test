package tests;

import base.BaseTest;
import pages.AttendancePage;
import pages.LoginPage;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class AttendanceTest extends BaseTest {

    @DataProvider(name = "loginData")
    public Object[][] loginData() {

        return new Object[][] {
            {
                "Sakshi02mishra11@gmail.com",
                System.getenv("FIELD_FORCE_PASSWORD")
            }
        };
    }

    @Test(dataProvider = "loginData")
    public void loginAndPunchIn(String email, String password) {

        Assert.assertNotNull(
                password,
                "FIELD_FORCE_PASSWORD environment variable is not set."
        );

        LoginPage loginPage =
                new LoginPage(driver);

        loginPage.login(email, password);

        wait.until(
                ExpectedConditions.urlContains("/dashboard")
        );

        System.out.println("Login successful.");
        System.out.println("Dashboard opened.");
        System.out.println("Email: " + email);

        AttendancePage attendancePage =
                new AttendancePage(driver);

        attendancePage.openAttendance();

        System.out.println(
                "Attendance page opened."
        );

        attendancePage.selectSakshi();

        System.out.println(
                "Sakshi selected."
        );

        attendancePage.punchIn();

        System.out.println(
                "Punch In action completed."
        );

        String toastMessage =
                attendancePage.getToastMessage();

        System.out.println(
                "Toast message captured: "
                + toastMessage
        );

        Assert.assertFalse(
                toastMessage.isEmpty(),
                "No toast/popup message appeared after Punch In"
        );

        boolean punchedIn =
                attendancePage.isPunchInSuccessful();

        Assert.assertTrue(
                punchedIn,
                "Punch In was not successful. "
                + "Check geofence/Allow Punch In-Out settings "
                + "and application response."
        );

        System.out.println(
                "================================"
        );

        System.out.println(
                "LOGIN + PUNCH IN + TOAST VALIDATION PASSED"
        );

        System.out.println(
                "================================"
        );
    }
}
